import React from 'react';

export default function SigninPage() {
  return (
    <div>
      Sign in
    </div>
  );
}
