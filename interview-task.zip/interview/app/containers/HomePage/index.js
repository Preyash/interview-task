import React from 'react';
import SignupForm from '../../components/SignupForm';

export default function HomePage() {
  return (
    <div className="page">
      <SignupForm/>
    </div>
  );
}
